## `config` Directory
The config directory contains various configurations that are used during installation of your theme.

### Directories
* install
* optional
* schema

### Resources
* [Configuration Storage in Drupal 8](https://www.drupal.org/node/2120571)

