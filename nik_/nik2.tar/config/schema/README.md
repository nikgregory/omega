## `config/schema` Directory
The `config/schema` contains schema information related to your theme. 

### Resources

* [Configuration Schema/Metadata](https://www.drupal.org/node/1905070)
