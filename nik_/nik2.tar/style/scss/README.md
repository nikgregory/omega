# `style/scss` Directory
The `style/scss` directory contains all the SASS/SCSS for your theme.
