# `style` Directory
This directory is intended to contain all styles for your theme. 

Sub-directories include:
* `css` - Compiled CSS
* `scss` - Structured SASS/SCSS
